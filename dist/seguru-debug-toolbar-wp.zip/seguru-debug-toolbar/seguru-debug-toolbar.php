<?php
/**
 * Plugin Name:  Seguru Debug Toolbar
 * Plugin URI:   https://github.com/seguru-digital/seguru-debug-toolbar
 * Description:  Visual overlay for data-ref element labels. Shows section references on the front end for admins — useful for QA, revision feedback, and bug reporting.
 * Version:      1.0.0
 * Author:       Seguru Digital
 * Author URI:   https://seguru.digital
 * License:      MIT
 * License URI:  https://opensource.org/licenses/MIT
 * Requires PHP: 7.4
 * Requires at least: 5.8
 *
 * Install: Upload this plugin via wp-admin → Plugins → Add New → Upload,
 * or unzip into wp-content/plugins/seguru-debug-toolbar/.
 * Activate, then enable via Settings → General → "Seguru Debug Toolbar".
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Constants ─────────────────────────────────────────────────
define( 'SDT_VERSION', '1.0.0' );
define( 'SDT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SDT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ── Settings field (Settings → General) ───────────────────────
add_action( 'admin_init', function () {

    register_setting( 'general', 'seguru_debug_toolbar_enabled', [
        'type'              => 'string',
        'sanitize_callback' => function ( $val ) { return $val === '1' ? '1' : '0'; },
        'default'           => '0',
    ] );

    add_settings_field(
        'seguru_debug_toolbar_enabled',
        'Seguru Debug Toolbar',
        function () {
            $val = get_option( 'seguru_debug_toolbar_enabled', '0' );
            echo '<label>';
            echo '<input type="checkbox" name="seguru_debug_toolbar_enabled" value="1"' . checked( $val, '1', false ) . ' />';
            echo ' Show debug toolbar on the front end for administrators';
            echo '</label>';
            echo '<p class="description">';
            echo 'Displays <code>data-ref</code> section labels on every tagged element. ';
            echo 'Press <kbd>L</kbd> to cycle between Icons, Off, and Full modes. ';
            echo 'Click any label to copy it.';
            echo '</p>';
        },
        'general',
        'default'
    );
} );

// ── Admin notice after activation ─────────────────────────────
register_activation_hook( __FILE__, function () {
    set_transient( 'sdt_activation_notice', true, 30 );
} );

add_action( 'admin_notices', function () {
    if ( ! get_transient( 'sdt_activation_notice' ) ) return;
    delete_transient( 'sdt_activation_notice' );
    echo '<div class="notice notice-info is-dismissible">';
    echo '<p><strong>Seguru Debug Toolbar</strong> is installed. ';
    echo 'Enable it under <a href="' . esc_url( admin_url( 'options-general.php' ) ) . '">Settings &rarr; General</a>.</p>';
    echo '</div>';
} );

// ── Enqueue on front end (admins only) ────────────────────────
add_action( 'wp_enqueue_scripts', function () {

    if ( get_option( 'seguru_debug_toolbar_enabled', '0' ) !== '1' ) return;
    if ( ! current_user_can( 'edit_theme_options' ) ) return;

    $file = SDT_PLUGIN_DIR . 'assets/seguru-debug-toolbar.min.js';

    if ( ! file_exists( $file ) ) return;

    wp_enqueue_script(
        'seguru-debug-toolbar',
        SDT_PLUGIN_URL . 'assets/seguru-debug-toolbar.min.js',
        [],
        SDT_VERSION,
        true
    );
} );
